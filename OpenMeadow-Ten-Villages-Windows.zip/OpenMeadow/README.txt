OPEN MEADOW - WINDOWS EDITION

1. Extract this ZIP to a folder.
2. Double-click OpenMeadow.exe.
3. Click Create character in the game window.
4. Choose your name, skin tone and bracers, then click Enter the castle.

For 64-bit Windows 10 and Windows 11, with Microsoft Edge installed.
No installer or administrator rights are needed. The solo game and its artwork
are included and work offline. Multiplayer needs a direct network connection. Edge provides the game window; the launcher
does not open or download the hosted website.

CONTROLS
W A S D       Walk
Mouse         Look around
Shift         Run
Space         Jump
Left click    Swing sword / punch
1 - 9         Select inventory slot
Mouse wheel   Cycle inventory slots
I             Open / close inventory
E             Open doors / talk / use chest / enter crypt
M             Open / close map and quest markers
J             Open / close quest journal
H             Drink healing potion (+50 health)
T             Light / extinguish offhand torch
F             Practice attack
Escape        Pause
Alt + Enter   Toggle full screen
Alt + F4      Close the game window

Use Nightfall / Daybreak to change the sky. Reset returns you to the castle.
Sound can be turned on using the Sound button.
Appearance reopens the character creator. Your choices are saved locally.
You begin with a longsword, torch and three healing potions.
Slots 1-2 hold your longsword and torch; slot 3 shows potions. H heals.
Slots 5-7 equip a purchased axe, tempered longsword or royal longsword.
Slot 8 equips your chosen extra weapon (or shows a quest parcel).
Choose extra weapons in Inventory; slot 9 shows moonflowers.
Click the potion slot, click the health HUD, or press H to heal.
Potions can be used inside Inventory and heal up to 50 HP.
At full health, no potion is consumed. Potions stored in your chest
must be taken out before use.
Enemy bones appear in slot 4 and can be sold at the market or stored.
The village of Alder is outside the north castle gate. Follow the lane
to its square; St. Alder Church has a door and a walkable nave.

THE ROYAL QUEST
Turn toward the rear keep in the castle. Press E to open its door, then
speak to King Aldric and accept his quest. M shows the crypt entrance
beyond the village church. Defeat all 10 skeletons and the armored captain.
The captain has 80 health and deals 16 damage; normal skeletons have
40 health and deal 8 damage. Sword hits deal 20 damage.
Return to the king to claim 1,000 gold and the eastern cottage near
the village square. Open its front door and use the chest inside to
store or retrieve your sword, torch, potions and bones.
Mara and Elin run the market. Potions cost 25 gold; bones sell for 5 gold.
Quest progress, defeated enemies, gold, health, bag and chest contents
save locally. If defeated, you return healed to the castle and keep
your quest progress.

THE FRONTIER
Willowbrook lies west of Alder; Stoneford lies east. M shows both towns
and roads. Elder Iris offers a delivery quest, Bram the smith buys six
bones, and Nora needs three moonflowers that only open at night.
Three bone urns in the crypt let you finish Bram's quest even if every
skeleton was already defeated and you sold your earlier loot.
Merchants sell an iron battle axe (180 gold, 32 damage, slower swing),
a tempered longsword (250 gold, 30 damage), and a royal longsword
(500 gold, 40 damage). New weapons can also be stored in your chest.
Press E beside a bed to sleep until morning or nightfall and heal fully.
Beds are available in the castle, the Alder inn and both new town inns,
as well as your earned house.

TWO-PLAYER DIRECT CO-OP
Open Multiplayer while paused. The host chooses Create invite and sends
the generated code to a friend who has the game. The friend pastes the
invite, chooses Join invite, and sends their reply back. The host pastes
that reply and chooses Connect reply. Close the panel to play together.
Position, crypt enemies, royal quest, doors and time are synchronized.
The host keeps the shared world. The guest uses a temporary session;
their original solo save returns when they leave. Side quests, purchases
and chest contents belong to each player during the session.
No public lobby or relay server is included. Direct connection depends
on network/firewall compatibility; try the same Wi-Fi if linking fails.
The connection logic was tested with simulated transports. A live
connection between two computers has not been verified in this build.

EMBERPEAK AND THE DRAGON SWORD
After claiming the royal quest reward, speak to Princess Elara in the
castle courtyard. Accept The Lost Tome, enter the crypt, and recover
the book from the far-right rear altar. Return it to Elara, then accept
the dragon hunt. Follow the marked stone trail east of Stoneford up
to Emberpeak. Ashwing lives on the actual mountain summit.
The dragon has 300 health. Its glowing throat warns of a fire attack:
move sideways to dodge. Its close-range bite can be avoided by backing
away. Defeat Ashwing to automatically receive and equip the Dragon Sword
in slot 1. One hit defeats any skeleton, including the armored captain.
The new sword can be stored in your house chest; while it is stored,
slot 1 holds your original longsword again.
Afterward, the crypt entrance offers a new skeleton patrol so you can
try the sword. This does not repeat the king's gold or house reward.

GRAPHICS
The default Smooth mode renders at higher resolution and uses smooth
scaling. Open Graphics to choose Sharper or Faster on your computer.
The artificial scanline overlay has been removed.

LOCAL FILES
The launcher saves the included game to:
%LOCALAPPDATA%\OpenMeadow\game-1.0.html
You can delete this folder when you no longer want the game.

BUILD NOTES
This is a portable, unsigned Windows executable. It is not an installer.
The executable format, embedded assets, offline scripts, launcher code,
Unicode-path handling and failure handling were checked. The executable
has not been run on a Windows computer in this environment.

TEN NEW VILLAGES
Briar Glen, Oakrest, Reedwater, Amberfield and Pinewatch lie along the
first southern road. Moss Hollow, Silvermere, Cinderwick, Frostford and
Sunhaven lie along the second. M shows every village and dungeon.
Leave Alder via the east road; the southern trail runs around the castle.
Each village has four houses, an inn bed, a weaponsmith, a quest giver
and a stone dungeon entrance north of the square. Speak to its quest
giver, clear its skeletons and guardian, then return for 220-650 gold
and two healing potions. Each reward is paid once. Dungeon progress
is saved independently, including when you retreat or are defeated.
J lists all ten quests. The king's crypt keeps its original progress.

NEW MERCHANT WEAPONS
Ranger sabre: 120 gold, 24 damage, quick swing.
Black iron cleaver: 360 gold, 46 damage, heavy swing.
Frostguard sword: 650 gold, 50 damage.
Sunsteel greatsword: 900 gold, 65 damage, slow swing.
These are available at all weapon merchants. Open Inventory and click
a weapon name to equip it in slot 8. Weapons can be stored at home.
The Dragon Sword still defeats any skeleton in one strike.
