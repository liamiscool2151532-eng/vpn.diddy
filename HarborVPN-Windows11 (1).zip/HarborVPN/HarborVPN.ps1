﻿# Harbor VPN - Windows 11 / Windows PowerShell 5.1
# Runs the official installed WireGuard client. No VPN servers are bundled.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    try {
        Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Verb RunAs -ArgumentList "-NoProfile -STA -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    } catch { [Windows.MessageBox]::Show('Administrator permission is required to manage VPN tunnels.', 'Harbor VPN') | Out-Null }
    exit
}

$script:root = Join-Path $env:ProgramData 'HarborVPN'
$script:regions = @(
    [pscustomobject]@{Name='United Kingdom'; Code='UK'; Tunnel='harbor-uk'},
    [pscustomobject]@{Name='United States'; Code='US'; Tunnel='harbor-us'},
    [pscustomobject]@{Name='Germany'; Code='DE'; Tunnel='harbor-de'}
)
$script:busy = $false
$script:wireguard = Join-Path $env:ProgramFiles 'WireGuard\wireguard.exe'
$script:wg = Join-Path $env:ProgramFiles 'WireGuard\wg.exe'

function Protect-Store {
    if (-not (Test-Path -LiteralPath $script:root)) {
        New-Item -ItemType Directory -Path $script:root | Out-Null
    }
    if ((Get-Item -LiteralPath $script:root).Attributes -band [IO.FileAttributes]::ReparsePoint) {
        throw 'The profile directory must not be a symbolic link or junction.'
    }
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $admins = New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')
    $system = New-Object Security.Principal.SecurityIdentifier('S-1-5-18')
    $acl.SetOwner($admins)
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @($admins, $system)) {
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid, 'FullControl', 'ContainerInherit, ObjectInherit', 'None', 'Allow')
        $acl.AddAccessRule($rule)
    }
    Set-Acl -LiteralPath $script:root -AclObject $acl
}

function Get-ProfilePath($region) { Join-Path $script:root ($region.Tunnel + '.conf') }
function Get-TunnelService($region) {
    Get-Service -Name ('WireGuardTunnel$' + $region.Tunnel) -ErrorAction SilentlyContinue
}
function Invoke-Native([string]$exe, [string]$arguments) {
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $exe
    $info.Arguments = $arguments
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $process = New-Object Diagnostics.Process
    $process.StartInfo = $info
    try {
        [void]$process.Start()
        $outTask = $process.StandardOutput.ReadToEndAsync()
        $errTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(15000)) {
            $process.Kill()
            throw 'The command timed out. Check the tunnel state before retrying.'
        }
        $output = $outTask.GetAwaiter().GetResult()
        $null = $errTask.GetAwaiter().GetResult()
        # Never expose raw command errors: they may contain profile information.
        if ($process.ExitCode -ne 0) { throw 'WireGuard could not complete the request. Check your configuration in the official WireGuard app.' }
        return $output
    } finally { $process.Dispose() }
}

function Assert-Profile([string]$text) {
    # Strict subset: disallow command hooks and unknown options in privileged configs.
    $section = ''
    $privateKey = $false; $address = $false; $dns = $false; $peerCount = 0
    $peerKey = $false; $endpoint = $false; $routes = @()
    foreach ($line in ($text -split '\r?\n')) {
        $line = ($line -split '#', 2)[0].Trim()
        if (-not $line) { continue }
        if ($line -match '^\[(Interface|Peer)\]$') {
            if ($Matches[1] -eq 'Interface' -and $section) { throw 'Use one Interface followed by one Peer.' }
            $section = $Matches[1]
            if ($section -eq 'Peer') { $peerCount++ }
            continue
        }
        if ($line -notmatch '^([A-Za-z]+)\s*=\s*(.+)$') { throw 'The configuration contains an invalid line.' }
        $key = $Matches[1]; $value = $Matches[2].Trim()
        if ($section -eq 'Interface') {
            if ($key -notin @('PrivateKey','Address','DNS','MTU','ListenPort')) { throw 'Unsupported Interface option. Command hooks are not permitted.' }
            if ($key -eq 'PrivateKey') { $privateKey = $value -match '^[A-Za-z0-9+/]{43}=$' }
            if ($key -eq 'Address') { $address = $true }
            if ($key -eq 'DNS') { $dns = $true }
        } elseif ($section -eq 'Peer') {
            if ($key -notin @('PublicKey','PresharedKey','Endpoint','AllowedIPs','PersistentKeepalive')) { throw 'Unsupported Peer option.' }
            if ($key -eq 'PublicKey') { $peerKey = $value -match '^[A-Za-z0-9+/]{43}=$' }
            if ($key -eq 'Endpoint') { $endpoint = $true }
            if ($key -eq 'AllowedIPs') { $routes += @($value -split ',' | ForEach-Object { $_.Trim() }) }
        } else { throw 'A configuration section is missing.' }
    }
    if (-not ($privateKey -and $address -and $dns -and $peerKey -and $endpoint -and $peerCount -eq 1)) {
        throw 'Use a standard single-server WireGuard profile with PrivateKey, Address, DNS, PublicKey and Endpoint.'
    }
    if ('0.0.0.0/0' -notin $routes -or '::/0' -notin $routes) {
        throw 'This app requires full-tunnel profiles: AllowedIPs must include 0.0.0.0/0 and ::/0. Ask your provider for a compatible profile.'
    }
}

[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="Harbor VPN" Width="850" Height="650" MinWidth="730" MinHeight="590" WindowStartupLocation="CenterScreen" Background="#0C1220" Foreground="#E9EEF8" FontFamily="Segoe UI">
 <Window.Resources>
  <Style TargetType="Button"><Setter Property="Foreground" Value="#E9EEF8"/><Setter Property="Background" Value="#24354D"/><Setter Property="BorderThickness" Value="0"/><Setter Property="Padding" Value="18,12"/><Setter Property="Margin" Value="0,0,10,0"/><Setter Property="Cursor" Value="Hand"/><Setter Property="FontSize" Value="14"/></Style>
  <Style TargetType="ComboBoxItem"><Setter Property="Foreground" Value="#111827"/><Setter Property="Padding" Value="12"/></Style>
 </Window.Resources>
 <Grid Margin="34">
  <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
  <DockPanel><TextBlock Text="HARBOR / VPN" FontWeight="Bold" FontSize="23"/><TextBlock Text="WIREGUARD  /  WINDOWS 11" Foreground="#96A8C4" HorizontalAlignment="Right" VerticalAlignment="Center" FontSize="11"/></DockPanel>
  <Grid Grid.Row="1" Margin="0,30,0,22">
   <Grid.ColumnDefinitions><ColumnDefinition Width="1.05*"/><ColumnDefinition Width="24"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
   <Border Background="#142033" CornerRadius="18" Padding="26">
    <StackPanel VerticalAlignment="Center">
     <TextBlock Text="YOUR CONNECTION" Foreground="#96A8C4" FontSize="12"/>
     <Border x:Name="StatusOrb" Width="100" Height="100" CornerRadius="50" Background="#24354D" Margin="0,25,0,20" HorizontalAlignment="Left"><TextBlock Text="H" FontSize="44" FontWeight="Light" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border>
     <TextBlock x:Name="StatusTitle" Text="Disconnected" FontSize="29" FontWeight="SemiBold"/>
     <TextBlock x:Name="StatusDetail" Text="Import a server profile to begin." Foreground="#AEBBD0" TextWrapping="Wrap" Margin="0,10,0,24"/>
     <Button x:Name="ConnectButton" Content="Connect" Background="#247A65" HorizontalAlignment="Stretch" Margin="0,0,0,10"/>
     <Button x:Name="DisconnectButton" Content="Disconnect all Harbor tunnels" Margin="0"/>
    </StackPanel>
   </Border>
   <StackPanel Grid.Column="2" VerticalAlignment="Center">
    <TextBlock Text="Choose your location" FontSize="22" FontWeight="SemiBold"/>
    <TextBlock Text="Three regions. Your own server profiles." Foreground="#96A8C4" Margin="0,7,0,20"/>
    <ComboBox x:Name="RegionBox" FontSize="16" Height="46" DisplayMemberPath="Name"/>
    <TextBlock x:Name="ProfileLabel" Text="No profile imported" Foreground="#AEBBD0" Margin="0,14,0,18"/>
    <WrapPanel><Button x:Name="ImportButton" Content="Import .conf"/><Button x:Name="RemoveButton" Content="Remove"/></WrapPanel>
    <Border Background="#142033" CornerRadius="12" Padding="17" Margin="0,24,0,0"><TextBlock Text="Bring your own VPN&#10;&#10;Import a WireGuard configuration for each country from your provider or a server you control. Server location is based on the profile you import." Foreground="#AEBBD0" TextWrapping="Wrap" FontSize="13"/></Border>
   </StackPanel>
  </Grid>
  <TextBlock Grid.Row="2" Text="A recent handshake confirms a responding peer. It does not verify internet access or prevent every leak.&#10;Closing this window leaves the tunnel running. Use Disconnect to stop it." Foreground="#96A8C4" TextWrapping="Wrap" FontSize="11"/>
 </Grid>
</Window>
'@
$reader = New-Object Xml.XmlNodeReader($xaml)
$script:window = [Windows.Markup.XamlReader]::Load($reader)
foreach ($name in @('RegionBox','StatusOrb','StatusTitle','StatusDetail','ProfileLabel','ConnectButton','DisconnectButton','ImportButton','RemoveButton')) {
    Set-Variable -Scope Script -Name $name -Value $script:window.FindName($name)
}
$script:RegionBox.ItemsSource = $script:regions
$script:RegionBox.SelectedIndex = 0

function Update-Status {
    $region = $script:RegionBox.SelectedItem
    if ($null -eq $region) { return }
    $hasProfile = Test-Path -LiteralPath (Get-ProfilePath $region)
    $script:ProfileLabel.Text = if ($hasProfile) { 'Profile ready / ' + $region.Code } else { 'No profile imported / ' + $region.Code }
    $script:ConnectButton.IsEnabled = (-not $script:busy) -and $hasProfile -and (Test-Path -LiteralPath $script:wireguard)
    $script:DisconnectButton.IsEnabled = -not $script:busy
    $script:ImportButton.IsEnabled = -not $script:busy
    $script:RemoveButton.IsEnabled = (-not $script:busy) -and $hasProfile
    $script:StatusTitle.Text = 'Disconnected'
    $script:StatusDetail.Text = 'Select a location and connect.'
    $script:StatusOrb.Background = '#24354D'
    if (-not (Test-Path -LiteralPath $script:wireguard)) {
        $script:StatusDetail.Text = 'Install the official WireGuard for Windows client first.'
        return
    }
    foreach ($candidate in $script:regions) {
        $service = Get-TunnelService $candidate
        if ($null -ne $service) {
            $script:StatusTitle.Text = 'Tunnel installed'
            $script:StatusDetail.Text = $candidate.Name + ' / service: ' + $service.Status
            if ($service.Status -eq 'Running') {
                $script:StatusTitle.Text = 'Awaiting handshake'
                $script:StatusDetail.Text = $candidate.Name + ' / interface active; peer not yet verified.'
                if (Test-Path -LiteralPath $script:wg) {
                    try {
                        $result = Invoke-Native $script:wg ('show ' + $candidate.Tunnel + ' latest-handshakes')
                        foreach ($row in ($result -split '\r?\n')) {
                            if ($row -match '\s(\d+)\s*$') {
                                $stamp = [long]$Matches[1]
                                $age = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - $stamp
                                if ($stamp -gt 0 -and $age -ge 0 -and $age -lt 180) {
                                    $script:StatusTitle.Text = 'Peer responding'
                                    $script:StatusDetail.Text = $candidate.Name + ' / handshake ' + $age + ' seconds ago.'
                                    $script:StatusOrb.Background = '#247A65'
                                }
                            }
                        }
                    } catch { $script:StatusDetail.Text = $candidate.Name + ' / status could not be verified.' }
                }
            }
            break
        }
    }
}
function Run-Action([scriptblock]$action) {
    if ($script:busy) { return }
    $script:busy = $true
    $script:timer.Stop()
    Update-Status
    $script:window.Cursor = [Windows.Input.Cursors]::Wait
    try { & $action } catch { [Windows.MessageBox]::Show($_.Exception.Message, 'Harbor VPN', 'OK', 'Warning') | Out-Null }
    finally {
        $script:busy = $false
        $script:window.Cursor = $null
        Update-Status
        $script:timer.Start()
    }
}
function Stop-HarborTunnels {
    foreach ($region in $script:regions) {
        if ($null -ne (Get-TunnelService $region)) {
            $null = Invoke-Native $script:wireguard ('/uninstalltunnelservice ' + $region.Tunnel)
            $deadline = [DateTime]::UtcNow.AddSeconds(8)
            while ($null -ne (Get-TunnelService $region)) {
                if ([DateTime]::UtcNow -gt $deadline) { throw 'The previous tunnel is still being removed. Retry shortly.' }
                Start-Sleep -Milliseconds 200
            }
        }
    }
}
$script:RegionBox.Add_SelectionChanged({ Update-Status })
$script:ImportButton.Add_Click({ Run-Action {
    $region = $script:RegionBox.SelectedItem
    if ($null -ne (Get-TunnelService $region)) { throw 'Disconnect this profile before replacing it.' }
    $dialog = New-Object Microsoft.Win32.OpenFileDialog
    $dialog.Filter = 'WireGuard configuration (*.conf)|*.conf'
    if ($dialog.ShowDialog($script:window)) {
        if ((Get-Item -LiteralPath $dialog.FileName).Length -gt 65536) { throw 'Profile exceeds the 64 KB limit.' }
        $text = [IO.File]::ReadAllText($dialog.FileName)
        Assert-Profile $text
        Protect-Store
        $destination = Get-ProfilePath $region
        # Delete the previous directory entry instead of following a link or retaining old ACLs.
        if (Test-Path -LiteralPath $destination) { Remove-Item -LiteralPath $destination -Force }
        [IO.File]::WriteAllText($destination, $text, (New-Object Text.UTF8Encoding($false)))
    }
} })
$script:ConnectButton.Add_Click({ Run-Action {
    $region = $script:RegionBox.SelectedItem
    $config = Get-ProfilePath $region
    if (-not (Test-Path -LiteralPath $script:wireguard)) { throw 'Install WireGuard for Windows first.' }
    if (-not (Test-Path -LiteralPath $config)) { throw 'Import a profile for this country first.' }
    if ((Get-Item -LiteralPath $config).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Profile links are not allowed.' }
    Assert-Profile ([IO.File]::ReadAllText($config))
    # Avoid interfering with VPNs managed by another application.
    $ours = @($script:regions | ForEach-Object { 'WireGuardTunnel$' + $_.Tunnel })
    $other = @(Get-Service -ErrorAction Stop | Where-Object { $_.Name.StartsWith('WireGuardTunnel$') -and $_.Name -notin $ours -and $_.Status -ne 'Stopped' })
    if ($other.Count -gt 0) { throw 'Disconnect other WireGuard tunnels in their own app first.' }
    Stop-HarborTunnels
    $null = Invoke-Native $script:wireguard ('/installtunnelservice "' + $config + '"')
} })
$script:DisconnectButton.Add_Click({ Run-Action { Stop-HarborTunnels } })
$script:RemoveButton.Add_Click({ Run-Action {
    $region = $script:RegionBox.SelectedItem
    if ($null -ne (Get-TunnelService $region)) { throw 'Disconnect this profile before removing it.' }
    $confirm = [Windows.MessageBox]::Show(('Remove the saved ' + $region.Name + ' profile?'), 'Harbor VPN', 'YesNo', 'Question')
    if ($confirm -eq 'Yes') { Remove-Item -LiteralPath (Get-ProfilePath $region) -Force }
} })
$script:timer = New-Object Windows.Threading.DispatcherTimer
$script:timer.Interval = [TimeSpan]::FromSeconds(5)
$script:timer.Add_Tick({ Update-Status })
$script:window.Add_Closed({ $script:timer.Stop() })
try {
    Protect-Store
    Update-Status
    $script:timer.Start()
    [void]$script:window.ShowDialog()
} catch {
    [Windows.MessageBox]::Show($_.Exception.Message, 'Harbor VPN startup error') | Out-Null
    exit 1
}
