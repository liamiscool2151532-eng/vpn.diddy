# Harbor VPN for Windows 11

A small desktop WireGuard controller with **United Kingdom, United States, and Germany** profile slots. It connects through the official WireGuard Windows client. No servers, subscriptions, accounts, or working credentials are included.

## Start

1. Install [WireGuard for Windows](https://www.wireguard.com/install/).
2. Obtain three WireGuard `.conf` files from your VPN provider or servers you control: one each for the UK, US, and Germany. Your provider must support exporting standard WireGuard profiles.
3. Extract this entire ZIP to a local folder. Review the included PowerShell source, then double-click `Start-HarborVPN.cmd` and approve the Windows administrator prompt.
4. Select **United Kingdom**, click **Import .conf**, and select its configuration. Repeat for **United States** and **Germany**.
5. Select a country and click **Connect**. Visit a trusted IP-check website to confirm the exit country. Test DNS and IPv6 handling before relying on the connection.
6. Click **Disconnect all Harbor tunnels** when finished. Closing the app leaves the tunnel running, including across Windows restarts because WireGuard installs a Windows service.

This is a runnable PowerShell/WPF desktop application, not a compiled or signed `.exe`. Windows PowerShell 5.1 and WPF are built into Windows 11. The launcher sets execution policy to Bypass for its process and elevated child only; it does not change the machine's execution policy. Managed PCs may prohibit running unsigned scripts. Do not change your organization's policies to run this app.

## Profile requirements

Use a standard profile with one `[Interface]`, one `[Peer]`, a private key, interface address, DNS, peer public key, endpoint, and `AllowedIPs = 0.0.0.0/0, ::/0`. Both default routes are required to avoid accepting an IPv4-only split-tunnel configuration. A working endpoint, valid keys, DNS, IPv6 handling, and server-side forwarding must be supplied by your provider. WireGuard performs the detailed configuration validation.

Command hooks (`PreUp`, `PostUp`, `PreDown`, `PostDown`), unknown options, multiple peers, encrypted `.conf.dpapi` imports, and nonstandard WireGuard extensions are rejected. There are no bundled or invented endpoints. Country labels describe the slot you choose; the app does not geolocate or independently verify your server.

## Connection status

- **Disconnected:** no Harbor tunnel service was found.
- **Tunnel installed:** a Harbor service exists; its current Windows service status is shown.
- **Awaiting handshake:** the service is running, but no peer handshake in the past 180 seconds was observed.
- **Peer responding:** WireGuard reports a recent handshake. This does not prove internet reachability, location, DNS routing, or leak protection. An idle connection can age back to Awaiting handshake.

Switching countries removes existing Harbor tunnels before installing the selected one. If switching fails, you may be disconnected. Other active WireGuard tunnels are detected and must be disconnected using their own app. Avoid using another VPN client simultaneously. There may be a short pause while Windows performs service operations.

## Privacy and limitations

Imported keys are stored as **plaintext** configuration files in `%ProgramData%\HarborVPN`, with directory access restricted to Administrators and SYSTEM. The app does not encrypt those files, erase the original imports, or securely erase deleted files. Protect your original profiles and use Windows disk encryption where appropriate. Local administrators can access the keys. The app sends no telemetry and makes no geolocation requests; WireGuard contacts the endpoint in your profile.

There is no independently implemented kill switch, automatic reconnect supervisor, tray icon, speed display, startup UI, or DNS/IPv6 leak test. WireGuard and Windows control networking and firewall behavior. Do not assume anonymity or leak protection from a green status indicator. This prototype has not undergone a security audit.

## Remove

Disconnect all Harbor tunnels, remove each profile in the app, then delete the extracted app folder. You can also remove `harbor-uk`, `harbor-us`, and `harbor-de` through the official WireGuard app if they appear there. Do not delete saved configuration files while a tunnel is installed: it may need them when restarting. WireGuard itself is installed separately and can be removed through Windows Settings.

## Validation

Created in a Linux workspace. The embedded XAML and package contents were checked statically. Windows PowerShell execution, WPF rendering, administrator elevation, WireGuard service lifecycle, and real traffic routing have **not** been tested on Windows. Test on a Windows 11 machine with valid server profiles before relying on it.

WireGuard integration follows its [official Windows service documentation](https://git.zx2c4.com/wireguard-windows/about/docs/enterprise.md). WireGuard is a separate third-party dependency; Harbor VPN is an independent example project.
